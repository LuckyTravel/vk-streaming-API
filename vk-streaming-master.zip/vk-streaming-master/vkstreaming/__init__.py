# -*- coding: utf-8 -*-

"""
@author: Daniil Suvorov
@contact: https://severecloud.me
"""
from .core import *

__author__ = 'Daniil Suvorov'
__version__ = '0.4'
__email__ = 'severecloud@gmail.com'
__contact__ = 'https://severecloud.me'
